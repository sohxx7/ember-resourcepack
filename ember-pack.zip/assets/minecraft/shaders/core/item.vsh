#version 330
#extension GL_ARB_separate_shader_objects : require

// 불씨: 바닐라 item.vsh 확장. ItemDisplay의 밝기 덮어쓰기(블록광, 하늘광)를 "모드 번호"로 쓴다.
//   블록광 15 + 하늘광 4 : 포스트 셰이더로 보내는 데이터 픽셀
//   블록광 15 + 하늘광 6 : 자체발광 (명암 없음)
//   블록광 14 + 하늘광 N : 절차적 이펙트 N번 (item.fsh의 runFx)
//   블록광 13 + 하늘광 N : 시간과 상관없는 자국 N번 (핏자국, 그을음). 서버가 지울 때까지 그대로 있다.
// 나머지는 바닐라와 같다.

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

layout(location = 7) flat out int eFam;
layout(location = 8) flat out vec4 eData;
layout(location = 9) out vec2 eUV;
layout(location = 10) flat out vec4 eColA;
layout(location = 11) flat out vec4 eColB;
layout(location = 12) flat out vec4 eColC;
layout(location = 13) out vec3 eView;

// 쿼드의 어느 귀퉁이인지는 uv 소수부로 안다. 모델은 네 귀퉁이가 한 텍셀 안의 서로 다른 점을 가리키게 만들어 둔다.
vec2 quadCorner(float backFace) {
    vec2 f = fract(UV0 * vec2(textureSize(Sampler0, 0)));
    vec2 c = vec2(f.x < 0.5 ? -1.0 : 1.0, f.y < 0.5 ? 1.0 : -1.0);
    return backFace > 0.5 ? vec2(-c.x, c.y) : c;
}

vec4 encode24(int v) {
    return vec4(float((v >> 16) & 255), float((v >> 8) & 255), float(v & 255), 255.0) / 255.0;
}

int fixed24(float x, float lo, float hi) {
    return int(clamp((x - lo) / (hi - lo), 0.0, 1.0) * 16777215.0);
}

int fixed12(float x, float lo, float hi) {
    return int(clamp((x - lo) / (hi - lo), 0.0, 1.0) * 4095.0);
}

void main() {
    vec3 pos = Position;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    int block = UV2.x >> 4;
    int sky = UV2.y >> 4;
    eFam = 0;
    eData = vec4(0.0);
    eUV = vec2(0.0);
    eColA = vec4(0.0);
    eColB = vec4(0.0);
    eColC = vec4(0.0);

    bool custom = false;
    bool nolight = false;

    if (block == 15 && sky == 4) {
        custom = true;
        // 데이터 픽셀: 화면 왼쪽 아래 구석의 픽셀로 강제 배치한다.
        int slot = int(texelFetch(Sampler0, ivec2(UV0 * vec2(textureSize(Sampler0, 0))), 0).r * 255.0 + 0.5);
        vec2 c = quadCorner(0.0) * 0.5 + 0.5;
        vec2 px = vec2(float(slot % 16) + c.x, c.y);
        vec2 ndc = px / ScreenSize * 2.0 - 1.0;
        float near = 0.055;
        gl_Position = vec4(ndc, (ProjMat[2][2] * -near + ProjMat[3][2]) / near, 1.0);
        eFam = 100;
        eColA = Color;
        // 서버가 모르는 값(투영과 시선)은 여기서 채운다.
        if (slot == 9) {
            eColA = encode24(fixed24(ProjMat[2][2], -2.0, 2.0));
        } else if (slot == 10) {
            eColA = encode24(fixed24(ProjMat[3][2], -1.0, 1.0));
        } else if (slot == 11) {
            // 시선 방향: ModelViewMat의 2행 2열은 위쪽 축의 시야 z 성분 → 피치
            float pitch = asin(clamp(-ModelViewMat[1][2], -1.0, 1.0));
            eColA = encode24((fixed12(ProjMat[1][1], 0.0, 8.0) << 12) | fixed12(pitch, -1.5707964, 1.5707964));
        } else if (slot == 12) {
            float y = float(CameraBlockPos.y) + CameraOffset.y;
            eColA = encode24(fixed12((y + 64.0) * 4.0, 0.0, 4095.0) << 12);
        }
    } else if (block == 15 && sky == 6) {
        custom = true;
        nolight = true;
    } else if (block == 14 || block == 13) {
        // 절차적 이펙트. 틴트 24비트: 시작틱 8, 수명 6, a 6, b 4
        custom = true;
        int d = (int(Color.r * 255.0 + 0.5) << 16) | (int(Color.g * 255.0 + 0.5) << 8) | int(Color.b * 255.0 + 0.5);
        float start = float((d >> 16) & 255);
        float life = float(((d >> 10) & 63) + 1);
        float a = float((d >> 4) & 63);
        float b = float(d & 15);
        float now = GameTime * 24000.0;
        float age = mod(now - start, 256.0);
        eFam = (block == 14 ? 10 : 30) + sky;
        eData = block == 14 ? vec4(age / life, life, a, b) : vec4(0.5, life, a, b);
        ivec2 tsz = textureSize(Sampler0, 0);
        ivec2 tx = ivec2(UV0 * vec2(tsz));
        eColA = texelFetch(Sampler0, tx + ivec2(0, 0), 0);
        eColB = texelFetch(Sampler0, tx + ivec2(1, 0), 0);
        eColC = texelFetch(Sampler0, tx + ivec2(2, 0), 0);
        float back = texelFetch(Sampler0, tx + ivec2(3, 0), 0).r;
        eUV = quadCorner(back);
        nolight = true;
    }

    eView = pos;

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    #endif

    if (eFam >= 10 && eFam < 100) {
        vertexColor = vec4(1.0);
    } else if (nolight) {
        vertexColor = Color;
    } else {
        vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    }

    #ifndef OIT_ALPHA_ONLY
    if (custom) {
        lightMapColor = vec4(1.0);
        overlayColor = vec4(0.0, 0.0, 0.0, 1.0);
    } else {
        lightMapColor = sample_lightmap(Sampler2, UV2);
        overlayColor = texelFetch(Sampler1, UV1, 0);
    }
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
