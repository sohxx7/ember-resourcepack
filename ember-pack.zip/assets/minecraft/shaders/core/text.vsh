#version 330
#extension GL_ARB_separate_shader_objects : require

// 불씨 HUD: 글자 색 24비트를 자료로 쓴다. 표는 ui/Hud.java 와 같다.
//   R 0xFE: 글자 라벨. G가 자리 번호, B가 색(하위 4비트)+그림자(0x10)+투명도(상위 3비트).
//           라벨은 항상 우두머리 막대 첫 줄(또는 둘째 줄)에 "순전진 0"으로 깔린다. 즉 글리프 x는 화면 가운데가 시작점이다.
//   R 0xC0~0xFD + 글리프 네 귀퉁이 표식: 위젯. R이 위젯 번호, G와 B가 값.
// 좌표 단위는 화면 높이의 1/1080. GUI 배율과 상관없이 같은 크기로 보인다.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out ivec3 hudData;
layout(location = 5) out vec2 hudUV;
layout(location = 6) flat out vec2 hudSize;

#ifdef IS_GUI
const vec3 LABEL_COLORS[12] = vec3[12](
    vec3(0.93, 0.90, 0.84),   // 0 바랜 흰색
    vec3(1.00, 0.55, 0.16),   // 1 불씨 주황
    vec3(0.95, 0.24, 0.20),   // 2 위험 빨강
    vec3(0.56, 0.86, 0.32),   // 3 감염 초록
    vec3(0.58, 0.60, 0.62),   // 4 회색
    vec3(0.98, 0.82, 0.42),   // 5 금빛
    vec3(0.52, 0.78, 0.95),   // 6 무전 파랑
    vec3(1.00, 1.00, 1.00),   // 7 흰색
    vec3(0.36, 0.38, 0.40),   // 8 어두운 회색
    vec3(0.62, 0.92, 0.70),   // 9 연두
    vec3(0.90, 0.62, 0.40),   // 10 살구
    vec3(0.10, 0.10, 0.11)    // 11 먹색
);

bool isMark(ivec2 t) {
    vec4 c = texelFetch(Sampler0, t, 0);
    return abs(c.r - 1.0 / 255.0) < 0.002 && abs(c.g - 2.0 / 255.0) < 0.002 && abs(c.b - 3.0 / 255.0) < 0.002 && c.a > 0.9;
}

// 라벨 자리. to: 글리프 시작점(유닛), anchor: 화면 기준점(0 왼쪽/위, 0.5 가운데, 1 오른쪽/아래), h: 글자 높이(유닛)
void labelSlot(int s, out vec2 to, out vec2 anchor, out float h) {
    to = vec2(0.0); anchor = vec2(0.5, 0.5); h = 26.0;
    // 0~3 임무 패널 (왼쪽 위)
    if (s == 0) { anchor = vec2(0.0, 0.0); to = vec2(52.0, 42.0); h = 30.0; }
    else if (s >= 1 && s <= 4) { anchor = vec2(0.0, 0.0); to = vec2(52.0, 82.0 + float(s - 1) * 32.0); h = 25.0; }
    // 5~12 팀 프레임 이름 (왼쪽 가운데)
    else if (s >= 5 && s <= 12) { anchor = vec2(0.0, 0.5); to = vec2(58.0, -170.0 + float(s - 5) * 54.0); h = 21.0; }
    // 13~20 재고 숫자 (오른쪽 위, 오른쪽 맞춤). 이름은 51~58, 제목은 59
    else if (s >= 13 && s <= 20) { anchor = vec2(1.0, 0.0); to = vec2(-30.0, 88.0 + float(s - 13) * 34.0); h = 25.0; }
    // 21~24 알림 줄 (오른쪽 가운데)
    else if (s >= 21 && s <= 24) { anchor = vec2(1.0, 0.5); to = vec2(-36.0, 60.0 + float(s - 21) * 34.0); h = 24.0; }
    // 25 상호작용 안내 (조준점 아래)
    else if (s == 25) { anchor = vec2(0.5, 0.5); to = vec2(0.0, 70.0); h = 26.0; }
    // 26~27 무전 자막
    else if (s == 26) { anchor = vec2(0.5, 1.0); to = vec2(0.0, -252.0); h = 22.0; }
    else if (s == 27) { anchor = vec2(0.5, 1.0); to = vec2(0.0, -224.0); h = 28.0; }
    else if (s == 42) { anchor = vec2(0.5, 1.0); to = vec2(0.0, -190.0); h = 28.0; }
    // 43~50 결과 화면
    else if (s == 43) { anchor = vec2(0.5, 0.5); to = vec2(0.0, -250.0); h = 42.0; }
    else if (s >= 44 && s <= 48) { anchor = vec2(0.5, 0.5); to = vec2(0.0, -170.0 + float(s - 44) * 56.0); h = 30.0; }
    else if (s == 49) { anchor = vec2(0.5, 0.5); to = vec2(0.0, 130.0); h = 32.0; }
    else if (s == 50) { anchor = vec2(0.5, 0.5); to = vec2(0.0, 182.0); h = 26.0; }
    // 28~29 큰 제목과 부제목
    else if (s == 28) { anchor = vec2(0.5, 0.42); to = vec2(0.0, -40.0); h = 118.0; }
    else if (s == 29) { anchor = vec2(0.5, 0.42); to = vec2(0.0, 66.0); h = 38.0; }
    // 30 우두머리 이름
    else if (s == 30) { anchor = vec2(0.5, 0.0); to = vec2(0.0, 176.0); h = 30.0; }
    // 31 쓰러짐 안내
    else if (s == 31) { anchor = vec2(0.5, 0.5); to = vec2(0.0, 150.0); h = 34.0; }
    // 32~ 는 둘째 줄: 자주 바뀌는 값
    // 32 탄창 숫자 / 33 예비탄 / 34 무기 이름
    else if (s == 32) { anchor = vec2(1.0, 1.0); to = vec2(-150.0, -96.0); h = 62.0; }
    else if (s == 33) { anchor = vec2(1.0, 1.0); to = vec2(-58.0, -82.0); h = 30.0; }
    else if (s == 34) { anchor = vec2(1.0, 1.0); to = vec2(-58.0, -128.0); h = 24.0; }
    // 35 시계 글자, 36 날짜
    else if (s == 35) { anchor = vec2(0.5, 0.0); to = vec2(0.0, 62.0); h = 30.0; }
    else if (s == 36) { anchor = vec2(0.5, 0.0); to = vec2(0.0, 20.0); h = 30.0; }
    // 37 체력 숫자
    else if (s == 37) { anchor = vec2(0.0, 1.0); to = vec2(44.0, -106.0); h = 44.0; }
    // 38 적재량 / 39 스킬 / 40 발전기 / 41 소생 진행
    else if (s == 38) { anchor = vec2(0.0, 1.0); to = vec2(134.0, -50.0); h = 22.0; }
    else if (s == 39) { anchor = vec2(1.0, 1.0); to = vec2(-58.0, -172.0); h = 22.0; }
    else if (s == 40) { anchor = vec2(0.5, 0.0); to = vec2(0.0, 108.0); h = 21.0; }
    else if (s == 41) { anchor = vec2(0.5, 0.5); to = vec2(0.0, 104.0); h = 24.0; }
    // 51~ 는 다시 첫 줄. 51~58 재고 이름(아이콘 오른쪽), 59 재고 판 제목
    else if (s >= 51 && s <= 58) { anchor = vec2(1.0, 0.0); to = vec2(-150.0, 89.5 + float(s - 51) * 34.0); h = 22.0; }
    else if (s == 59) { anchor = vec2(1.0, 0.0); to = vec2(-188.0, 54.0); h = 21.0; }
}

// 위젯 자리: center(유닛), size(유닛), anchor
void widgetLayout(int id, int g, int b, out vec2 center, out vec2 size, out vec2 anchor) {
    center = vec2(0.0); size = vec2(64.0); anchor = vec2(0.5, 0.5);
    if (id == 0xC0 || id == 0xC1) { anchor = vec2(0.0, 1.0); center = vec2(330.0, -84.0); size = vec2(400.0, 26.0); }   // 체력, 잔상
    else if (id == 0xC2) { anchor = vec2(0.0, 1.0); center = vec2(318.0, -62.0); size = vec2(376.0, 9.0); }              // 기력
    else if (id == 0xC3) { anchor = vec2(0.0, 1.0); center = vec2(574.0, -80.0); size = vec2(64.0); }                   // 감염 고리
    else if (id == 0xC4) { anchor = vec2(1.0, 1.0); center = vec2(-210.0, -92.0); size = vec2(370.0, 120.0); }          // 무기 판
    else if (id == 0xC5) { anchor = vec2(1.0, 1.0); center = vec2(-210.0, -38.0); size = vec2(330.0, 10.0); }           // 탄창 눈금
    else if (id == 0xC6) { size = vec2(46.0); }                                                                          // 재장전 고리 (조준점)
    else if (id == 0xC7) { size = vec2(140.0); }                                                                         // 조준점
    else if (id == 0xC8) { size = vec2(96.0); }                                                                          // 적중 표시
    else if (id == 0xC9) { size = vec2(92.0); }                                                                          // 상호작용 고리
    else if (id == 0xCA) { anchor = vec2(0.5, 0.0); center = vec2(0.0, 68.0); size = vec2(420.0, 124.0); }              // 시계 판
    else if (id == 0xCB) { anchor = vec2(0.5, 0.0); center = vec2(0.0, 114.0); size = vec2(360.0, 8.0); }               // 발전기 막대
    else if (id == 0xCC) { anchor = vec2(0.5, 0.0); center = vec2(0.0, 126.0); size = vec2(360.0, 5.0); }               // 연료 막대
    else if (id == 0xCD || id == 0xCE) { anchor = vec2(0.5, 0.0); center = vec2(0.0, 222.0); size = vec2(900.0, 22.0); } // 우두머리 막대, 잔상
    else if (id == 0xCF) { size = vec2(200.0); }                                                                         // 피격 방향
    else if (id == 0xD0) {                                                                                               // 나침반 항목: 16비트 각도
        float a = float(g * 256 + b) / 65536.0 * 6.2831853;
        if (a > 3.14159265) a -= 6.2831853;
        anchor = vec2(0.5, 0.0);
        center = vec2(a / 1.5707963 * 300.0, 158.0);
        size = vec2(26.0);
    }
    else if (id == 0xD1) { anchor = vec2(0.5, 0.0); center = vec2(0.0, 158.0); size = vec2(620.0, 30.0); }              // 나침반 띠
    else if (id == 0xD2) {                                                                                               // 팀 프레임 막대: g 줄, b 체력
        anchor = vec2(0.0, 0.5); center = vec2(148.0, -142.0 + float(g & 15) * 54.0); size = vec2(190.0, 9.0);
    }
    else if (id == 0xD3) { anchor = vec2(1.0, 1.0); center = vec2(-94.0, -196.0); size = vec2(74.0); }                  // 스킬 고리
    else if (id == 0xD4) { anchor = vec2(0.0, 0.0); center = vec2(320.0, 40.0 + float(g) * 16.0); size = vec2(600.0, 56.0 + float(g) * 32.0); } // 임무 판
    else if (id == 0xD5) { anchor = vec2(1.0, 0.0); center = vec2(-107.0, 67.0 + float(g) * 17.0); size = vec2(190.0, float(g) * 34.0 + 46.0); }  // 재고 판 (제목 한 줄 + g 줄)
    else if (id == 0xD6) { anchor = vec2(0.5, 1.0); center = vec2(0.0, -204.0); size = vec2(1060.0, 112.0); }           // 무전 판
    else if (id == 0xD7) { anchor = vec2(0.5, 0.42); center = vec2(0.0, 20.0); size = vec2(1500.0, 260.0); }            // 큰 제목 띠
    else if (id == 0xD8) { anchor = vec2(0.5, 0.5); center = vec2(0.0, 150.0); size = vec2(360.0, 12.0); }              // 쓰러짐 막대
    else if (id == 0xD9) {                                                                                               // 아이콘: g 자리
        if (g < 8) { anchor = vec2(1.0, 0.0); center = vec2(-174.0, 100.0 + float(g) * 34.0); size = vec2(28.0); }       // 재고
        else if (g < 16) { anchor = vec2(0.0, 0.5); center = vec2(36.0, -160.0 + float(g - 8) * 54.0); size = vec2(30.0); } // 팀
        else if (g == 16) { anchor = vec2(1.0, 1.0); center = vec2(-302.0, -92.0); size = vec2(108.0); }                 // 무기 그림
        else if (g == 17) { anchor = vec2(1.0, 1.0); center = vec2(-94.0, -196.0); size = vec2(44.0); }                  // 스킬 그림
        else if (g == 18) { anchor = vec2(0.0, 1.0); center = vec2(574.0, -80.0); size = vec2(32.0); }                   // 감염 그림
        else if (g == 20) { anchor = vec2(0.5, 1.0); center = vec2(-484.0, -204.0); size = vec2(64.0); }                 // 무전 화자
    }
    else if (id == 0xDB) {                                                                                               // 로고 조각: g = 줄<<2 | 칸
        float k = 960.0 / 988.0;
        anchor = vec2(0.5, 0.42);
        center = vec2((float(g & 3) - 1.5) * 246.0, (float(g >> 2) - 0.5) * 246.0) * k;
        size = vec2(250.0 * k);
    }
    else if (id == 0xDA) {                                                                                               // 화면 가장자리 위치 표시. g 각도, b 종류
        float a = float(g) / 256.0 * 6.2831853;
        vec2 dir = vec2(sin(a), -cos(a));
        center = dir * 330.0;
        size = vec2(36.0);
    }
}
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    hudData = ivec3(0);
    hudUV = vec2(0.0);
    hudSize = vec2(1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    ivec3 c = ivec3(Color.rgb * 255.0 + 0.5);
    if (c.r == 0xFE) {
        // 라벨: 글리프를 지정한 자리로 옮긴다.
        vec2 gui = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        float unit = gui.y / 1080.0;
        vec2 to, anchor;
        float h;
        labelSlot(c.g, to, anchor, h);
        float rowY = (c.g >= 32 && c.g <= 50) ? 22.0 : 3.0;  // 32~50만 둘째 줄(자주 바뀌는 글자)
        vec2 from = vec2(gui.x * 0.5, rowY);
        float scale = h * unit / 9.0;
        vec2 base = anchor * gui + to * unit;
        vec2 p = base + (Position.xy - from) * scale;
        gl_Position = ProjMat * ModelViewMat * vec4(p, Position.z, 1.0);
        int colorIndex = c.b & 15;
        bool shadow = (c.b & 16) != 0;
        float alpha = float((c.b >> 5) & 7) / 7.0;
        vertexColor = vec4(shadow ? vec3(0.015, 0.012, 0.012) : LABEL_COLORS[min(colorIndex, 11)], alpha * (shadow ? 0.8 : 1.0));
    } else if (c.r >= 0xC0 && c.r <= 0xFD) {
        ivec2 sz = textureSize(Sampler0, 0);
        vec2 tx = UV0 * vec2(sz);
        ivec2 t = ivec2(floor(tx + 0.5));
        vec2 corner = vec2(-1.0);
        if (isMark(t)) corner = vec2(0.0, 0.0);
        else if (isMark(t + ivec2(-1, 0))) corner = vec2(1.0, 0.0);
        else if (isMark(t + ivec2(0, -1))) corner = vec2(0.0, 1.0);
        else if (isMark(t + ivec2(-1, -1))) corner = vec2(1.0, 1.0);
        if (corner.x >= 0.0) {
            vec2 center, size, anchor;
            widgetLayout(c.r, c.g, c.b, center, size, anchor);
            float unit = ScreenSize.y / 1080.0;
            vec2 pos = anchor * ScreenSize + center * unit;
            float s = 1.0;
            vec2 p = pos + (corner - 0.5) * size * unit * s;
            vec2 ndc = p / ScreenSize * 2.0 - 1.0;
            gl_Position = vec4(ndc.x, -ndc.y, 0.0, 1.0);
            hudData = c;
            hudUV = corner;
            hudSize = size * unit * s;
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
#endif
}
