#version 330
#extension GL_ARB_separate_shader_objects : require

// 불씨: 바닐라 item.fsh 확장. 절차적 이펙트 판을 그린다.
// 이펙트 번호는 fx/Vfx.java와 같다. eData: x 진행도(0~1), y 수명, z a값(0~63), w b값(0~15)

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

layout(location = 7) flat in int eFam;
layout(location = 8) flat in vec4 eData;
layout(location = 9) in vec2 eUV;
layout(location = 10) flat in vec4 eColA;
layout(location = 11) flat in vec4 eColB;
layout(location = 12) flat in vec4 eColC;
layout(location = 13) in vec3 eView;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    if (eFam >= 10) {
        return color;
    }
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

const float PI = 3.14159265;
const float TAU = 6.2831853;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + 11.3;
        a *= 0.5;
    }
    return v;
}

// 이펙트별 그림. uv는 -1~1, p는 진행도, seed는 b값으로 만든 난수
vec4 fxTracer(vec2 uv, float p) {
    // 긴 판의 가운데 선. x 방향이 총알의 길이 방향이다.
    float head = mix(-1.3, 1.3, p);
    float along = smoothstep(1.3, 0.0, head - uv.x) * step(uv.x, head);
    float core = exp(-uv.y * uv.y * 40.0);
    float a = along * core * (1.0 - p);
    return vec4(mix(eColB.rgb, eColA.rgb, core), a);
}
vec4 fxGlow(vec2 uv, float p) {
    float r = length(uv);
    float a = pow(max(1.0 - r, 0.0), 2.2) * (1.0 - p) * (1.0 - p);
    return vec4(mix(eColB.rgb, eColA.rgb, smoothstep(0.1, 0.65, 1.0 - r)), a);
}
vec4 fxFire(vec2 uv, float p, float seed) {
    // 위로 타오르는 불꽃. 수명 내내 같은 세기이고 끝에서만 사그라진다.
    float t = GameTime * 24000.0;
    vec2 q = vec2(uv.x * 1.6, (uv.y + 1.0) * 0.9);
    float n = fbm(vec2(q.x * 2.6 + seed * 7.0, q.y * 1.9 - t * 0.085));
    float shape = 1.0 - length(vec2(uv.x * (1.0 + (uv.y + 1.0) * 0.7), (uv.y + 0.2) * 0.8));
    float f = shape + (n - 0.5) * 1.15;
    float fadeK = 1.0 - smoothstep(0.86, 1.0, p);
    float a = smoothstep(0.02, 0.32, f) * fadeK;
    vec3 c = mix(eColC.rgb, eColB.rgb, smoothstep(0.05, 0.42, f));
    c = mix(c, eColA.rgb, smoothstep(0.42, 0.86, f));
    return vec4(c, a);
}
vec4 fxSmoke(vec2 uv, float p, float seed) {
    float t = GameTime * 24000.0;
    float scale = 0.55 + p * 0.45;
    vec2 q = uv / scale;
    float r = length(q);
    float n = fbm(q * 2.3 + vec2(seed * 3.1, seed * 5.3 - t * 0.02));
    float a = smoothstep(1.0, 0.25, r + (n - 0.5) * 0.9);
    a *= smoothstep(0.0, 0.1, p) * pow(1.0 - p, 1.3) * 0.72;
    vec3 c = mix(eColC.rgb, eColB.rgb, n);
    return vec4(c, a);
}
vec4 fxRing(vec2 uv, float p) {
    float r = length(uv);
    float rad = 0.12 + p * 0.82;
    float w = mix(0.11, 0.015, p);
    float ring = smoothstep(w, 0.0, abs(r - rad));
    float a = ring * (1.0 - p) * (1.0 - p);
    return vec4(mix(eColB.rgb, eColA.rgb, ring), a);
}
vec4 fxSplat(vec2 uv, float p, float seed) {
    // 바닥이나 벽에 튄 자국. 처음에 빠르게 번지고 오래 남았다가 마지막에 옅어진다.
    float grow = 1.0 - pow(1.0 - clamp(p * 16.0, 0.0, 1.0), 3.0);
    float ang = atan(uv.y, uv.x);
    float r = length(uv) / max(grow, 0.02);
    float rays = fbm(vec2(ang * 3.0 + seed * 9.0, seed * 4.0));
    float rim = 0.34 + rays * 0.72;
    float body = smoothstep(rim, rim - 0.1, r);
    float dots = smoothstep(0.77, 0.86, fbm(uv * 8.0 + seed * 13.0)) * smoothstep(1.0, 0.45, r);
    float a = max(body, dots) * (1.0 - smoothstep(0.8, 1.0, p));
    float tone = fbm(uv * 5.0 + seed);
    vec3 c = mix(eColC.rgb, eColA.rgb, tone * 0.9);
    return vec4(c, a * 0.92);
}
vec4 fxPool(vec2 uv, float p, float seed) {
    // 산성 웅덩이: 가장자리가 끓는다.
    float t = GameTime * 24000.0;
    float grow = 1.0 - pow(1.0 - clamp(p * 10.0, 0.0, 1.0), 2.0);
    float r = length(uv) / max(grow, 0.02);
    float n = fbm(uv * 3.0 + vec2(seed * 3.0, t * 0.012));
    float body = smoothstep(0.92, 0.64, r + (n - 0.5) * 0.5);
    float bub = smoothstep(0.62, 0.74, vnoise(uv * 13.0 + vec2(0.0, t * 0.05)));
    float a = body * (1.0 - smoothstep(0.85, 1.0, p)) * 0.86;
    vec3 c = mix(eColC.rgb, eColB.rgb, n);
    c = mix(c, eColA.rgb, bub * body);
    return vec4(c, a);
}
vec4 fxCloud(vec2 uv, float p, float seed) {
    // 넓게 퍼지는 가스.
    float t = GameTime * 24000.0;
    float r = length(uv);
    float n = fbm(uv * 2.0 + vec2(t * 0.012 + seed, -t * 0.009));
    float a = smoothstep(1.0, 0.1, r + (n - 0.5) * 0.7) * smoothstep(0.0, 0.08, p) * (1.0 - smoothstep(0.72, 1.0, p)) * 0.68;
    return vec4(mix(eColC.rgb, eColA.rgb, n), a);
}
vec4 fxSpark(vec2 uv, float p, float seed) {
    float ang = atan(uv.y, uv.x);
    float r = length(uv);
    float rays = pow(abs(sin(ang * (3.0 + seed * 3.0) + seed * 6.0)), 18.0);
    float lim = 0.25 + p * 0.75;
    float a = rays * smoothstep(lim, lim * 0.4, r) + exp(-r * r * 60.0);
    a *= (1.0 - p);
    return vec4(mix(eColB.rgb, eColA.rgb, a), clamp(a, 0.0, 1.0));
}
vec4 fxBeam(vec2 uv, float p) {
    // 세로 빛기둥. y는 아래(-1)에서 위(1)로.
    float t = GameTime * 24000.0;
    float across = exp(-uv.x * uv.x * 7.0);
    float core = exp(-uv.x * uv.x * 90.0);
    float along = smoothstep(1.0, -0.3, uv.y);
    float n = 0.8 + 0.2 * vnoise(vec2(uv.y * 6.0 - t * 0.08, uv.x * 3.0));
    float fadeK = (1.0 - smoothstep(0.92, 1.0, p)) * smoothstep(0.0, 0.05, p);
    float a = (across * 0.38 + core * 0.62) * along * n * fadeK;
    // 판은 깊이를 쓴다. 옅은 가장자리까지 그리면 뒤 풍경의 안개가 판 모양으로 끊긴다.
    a = max(a - 0.03, 0.0);
    return vec4(mix(eColB.rgb, eColA.rgb, core), a);
}
vec4 fxMarker(vec2 uv, float p) {
    // 바닥의 원형 표지: 천천히 맥동한다.
    float t = GameTime * 24000.0;
    float r = length(uv);
    float pulse = fract(t * 0.022);
    float base = smoothstep(0.035, 0.0, abs(r - 0.92)) * 0.92;
    float wave = smoothstep(0.09, 0.0, abs(r - pulse * 0.92)) * (1.0 - pulse) * 0.5;
    float ang = atan(uv.y, uv.x);
    float ticks = smoothstep(0.035, 0.0, abs(r - 0.78)) * step(0.5, fract(ang / TAU * 16.0 + t * 0.006)) * 0.5;
    float a = (base + wave + ticks) * (1.0 - smoothstep(0.96, 1.0, p));
    return vec4(mix(eColB.rgb, eColA.rgb, base), a);
}
vec4 fxBurst(vec2 uv, float p, float seed) {
    // 폭발 불덩이.
    float grow = 1.0 - pow(1.0 - min(p * 2.4, 1.0), 2.6);
    float r = length(uv) / max(grow, 0.02);
    float ang = atan(uv.y, uv.x);
    float n = fbm(vec2(ang * 1.7 + seed * 5.0, r * 2.0 - p * 3.0));
    float f = 1.0 - r + (n - 0.5) * 0.85;
    float cool = smoothstep(0.1, 1.0, p);
    float a = smoothstep(0.0, 0.24, f) * (1.0 - smoothstep(0.55, 1.0, p));
    vec3 hot = mix(eColB.rgb, eColA.rgb, smoothstep(0.26, 0.74, f));
    vec3 c = mix(hot, eColC.rgb * 0.6, cool);
    return vec4(c, a);
}
vec4 fxScorch(vec2 uv, float p, float seed) {
    float r = length(uv);
    float n = fbm(uv * 3.6 + seed * 3.0);
    float a = smoothstep(1.0, 0.25, r + (n - 0.5) * 0.7) * (1.0 - smoothstep(0.75, 1.0, p)) * 0.82;
    return vec4(vec3(0.02), a);
}
vec4 fxCone(vec2 uv, float p) {
    // 남의 손전등 빛줄기. x가 길이 방향.
    float x = uv.x * 0.5 + 0.5;
    float w = mix(0.14, 1.0, x);
    float across = exp(-uv.y * uv.y / (w * w) * 3.2);
    float along = smoothstep(1.0, 0.0, x) * smoothstep(0.0, 0.05, x);
    float a = across * along * 0.3;
    return vec4(eColA.rgb, a);
}
vec4 fxHolo(vec2 uv, float p) {
    // 건설 설계도 판: 주사선과 테두리.
    float t = GameTime * 24000.0;
    float line = 0.55 + 0.45 * sin(uv.y * 60.0 - t * 0.5);
    float edge = smoothstep(0.03, 0.0, 1.0 - max(abs(uv.x), abs(uv.y)));
    float a = (0.1 + line * 0.14 + edge * 0.75) * (1.0 - smoothstep(0.95, 1.0, p));
    return vec4(mix(eColB.rgb, eColA.rgb, edge), a);
}
vec4 fxDebris(vec2 uv, float p, float seed) {
    // 돌가루와 파편이 튀는 판.
    float r = length(uv);
    float n = fbm(uv * 11.0 + seed * 3.0);
    float lim = 0.2 + p * 0.8;
    float a = smoothstep(0.7, 0.8, n) * smoothstep(lim, lim * 0.3, r) * (1.0 - p);
    return vec4(eColB.rgb, clamp(a * 1.4, 0.0, 1.0));
}

// 시간에 묶이지 않는 자국
vec4 fxDecalBlood(vec2 uv, float seed) {
    float ang = atan(uv.y, uv.x);
    float r = length(uv);
    float rays = fbm(vec2(ang * 3.0 + seed * 9.0, seed * 4.0));
    float rim = 0.34 + rays * 0.72;
    float body = smoothstep(rim, rim - 0.1, r);
    float dots = smoothstep(0.77, 0.86, fbm(uv * 8.0 + seed * 13.0)) * smoothstep(1.0, 0.45, r);
    float tone = fbm(uv * 5.0 + seed);
    return vec4(mix(eColC.rgb, eColA.rgb, tone * 0.9), max(body, dots) * 0.92);
}
vec4 fxDecalScorch(vec2 uv, float seed) {
    float r = length(uv);
    float n = fbm(uv * 3.6 + seed * 3.0);
    return vec4(vec3(0.02), smoothstep(1.0, 0.25, r + (n - 0.5) * 0.7) * 0.82);
}

vec4 runFx(int fam) {
    float p = eData.x;
    if (p >= 1.0) {
        return vec4(0.0);
    }
    float a = eData.z / 63.0;
    float seed = eData.w / 15.0 + a;
    vec2 uv = eUV;
    switch (fam) {
        case 10: return fxTracer(uv, p);
        case 11: return fxGlow(uv, p);
        case 12: return fxFire(uv, p, seed);
        case 13: return fxSmoke(uv, p, seed);
        case 14: return fxRing(uv, p);
        case 15: return fxSplat(uv, p, seed);
        case 16: return fxPool(uv, p, seed);
        case 17: return fxCloud(uv, p, seed);
        case 18: return fxSpark(uv, p, seed);
        case 19: return fxBeam(uv, p);
        case 20: return fxMarker(uv, p);
        case 21: return fxBurst(uv, p, seed);
        case 22: return fxScorch(uv, p, seed);
        case 23: return fxCone(uv, p);
        case 24: return fxHolo(uv, p);
        case 25: return fxDebris(uv, p, seed);
        case 30: return fxDecalBlood(uv, seed);
        case 31: return fxDecalScorch(uv, seed);
    }
    return vec4(0.0);
}

void main() {
    vec4 color;
    if (eFam == 100) {
        #ifndef OIT_ALPHA_ONLY
        fragColor = vec4(eColA.rgb, 1.0);
        #endif
        return;
    } else if (eFam >= 10) {
        color = runFx(eFam);
        // 넓은 판 안에 카메라가 들어가면 화면을 덮으니 가까울수록 옅게 한다.
        if (eFam == 13 || eFam == 17 || eFam == 21) {
            color.a *= 0.05 + 0.95 * smoothstep(0.6, 3.4, length(eView));
        }
        if (color.a < 0.012) {
            discard;
        }
    } else {
        color = texture(Sampler0, texCoord0);
        #ifdef ALPHA_CUTOUT
        if (color.a < ALPHA_CUTOUT) {
            discard;
        }
        #endif

        color *= vertexColor * ColorModulator;

        #ifdef GLINT
        color.a = max(color.a, GlintAlpha);
        #endif
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
