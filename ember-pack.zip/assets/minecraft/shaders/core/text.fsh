#version 330
#extension GL_ARB_separate_shader_objects : require

// 불씨 HUD: 위젯 그리기. 번호 표는 text.vsh 와 ui/Hud.java 와 같다.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in ivec3 hudData;
layout(location = 5) in vec2 hudUV;
layout(location = 6) flat in vec2 hudSize;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

#ifdef IS_GUI
const float PI = 3.14159265;
const float TAU = 6.2831853;

const vec3 EMBER = vec3(1.00, 0.53, 0.14);
const vec3 EMBER_DIM = vec3(0.55, 0.26, 0.07);
const vec3 BONE = vec3(0.93, 0.90, 0.84);
const vec3 DANGER = vec3(0.92, 0.20, 0.16);
const vec3 INFECT = vec3(0.50, 0.84, 0.24);
const vec3 COLD = vec3(0.50, 0.72, 0.92);
const vec4 PLATE = vec4(0.035, 0.035, 0.04, 0.62);

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}

float now() {
    return GameTime * 24000.0;
}

float age(int start) {
    return mod(now() - float(start), 256.0);
}

vec4 over(vec4 top, vec4 bottom) {
    float a = top.a + bottom.a * (1.0 - top.a);
    if (a <= 0.0001) return vec4(0.0);
    return vec4((top.rgb * top.a + bottom.rgb * bottom.a * (1.0 - top.a)) / a, a);
}

vec4 fetch(ivec2 t) {
    vec4 c = texelFetch(Sampler0, t, 0);
    if (abs(c.r - 1.0 / 255.0) < 0.002 && abs(c.g - 2.0 / 255.0) < 0.002 && abs(c.b - 3.0 / 255.0) < 0.002) {
        return vec4(0.0);
    }
    c.rgb *= c.a;
    return c;
}

// 글리프 그림을 부드럽게 읽는다. (글꼴 아틀라스는 최근접 필터)
vec4 glyph() {
    vec2 tsz = vec2(textureSize(Sampler0, 0));
    vec2 p = texCoord0 * tsz - 0.5;
    vec2 f = fract(p);
    ivec2 i = ivec2(floor(p));
    vec4 c = mix(mix(fetch(i), fetch(i + ivec2(1, 0)), f.x), mix(fetch(i + ivec2(0, 1)), fetch(i + ivec2(1, 1)), f.x), f.y);
    if (c.a > 0.001) {
        c.rgb /= c.a;
    }
    return c;
}

float frac16(ivec3 d) {
    return float(d.g * 256 + d.b) / 65535.0;
}

// 네모 SDF. p 픽셀, b 반너비
float sdBox(vec2 p, vec2 b) {
    vec2 d = abs(p) - b;
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

float aastep(float d) {
    return clamp(0.5 - d, 0.0, 1.0);
}

// 기울어진 막대. uv 0~1, px 전체 크기. 왼쪽에서 오른쪽으로 찬다.
vec4 skewBar(vec2 uv, vec2 px, float fill, vec3 colA, vec3 colB, float slant, bool bg, int notches) {
    vec2 p = (uv - 0.5) * px;
    p.x += (uv.y - 0.5) * slant;
    vec2 half_ = px * 0.5 - vec2(abs(slant) * 0.5 + 1.0, 1.0);
    float d = sdBox(p, half_);
    float body = aastep(d);
    if (body <= 0.001) return vec4(0.0);
    vec4 res = bg ? vec4(0.03, 0.03, 0.035, 0.66 * body) : vec4(0.0);
    float u = (p.x + half_.x) / (half_.x * 2.0);
    float e = 1.0 / px.x;
    float inFill = aastep((u - fill) * px.x);
    if (fill > 0.0005 && inFill > 0.0) {
        vec3 c = mix(colB, colA, smoothstep(0.0, 1.0, 1.0 - abs(uv.y - 0.4) * 2.0));
        float tip = smoothstep(fill - 0.012, fill - 0.001, u) * inFill;
        c = mix(c, vec3(1.0), tip * 0.55);
        res = over(vec4(c, inFill * body), res);
    }
    if (notches > 0) {
        float n = abs(fract(u * float(notches)) - 0.5) * 2.0;
        float tick = smoothstep(1.0 - 2.4 * float(notches) * e * 2.0, 1.0, n);
        res.rgb = mix(res.rgb, res.rgb * 0.45, tick * 0.8);
    }
    // 위쪽 얇은 빛줄
    float edge = aastep(abs(d + 0.5) - 0.5);
    res = over(vec4(BONE, edge * 0.22), res);
    return res;
}

// 고리 진행도. r0~r1 사이, p 0~1, 12시에서 시계 방향
vec4 ring(vec2 uv, vec2 px, float prog, float r0, float r1, vec3 col, float bgAlpha) {
    vec2 q = (uv - 0.5) * px;
    float r = length(q);
    float w = (r1 - r0) * 0.5;
    float m = (r1 + r0) * 0.5;
    float body = aastep(abs(r - m) - w);
    if (body <= 0.001) return vec4(0.0);
    float a = atan(q.x, -q.y) / TAU;
    if (a < 0.0) a += 1.0;
    float on = a <= prog ? 1.0 : 0.0;
    return mix(vec4(0.05, 0.05, 0.05, bgAlpha * body), vec4(col, body), on);
}

// 판: 모서리 잘린 어두운 사각형과 아래쪽 주황 줄
vec4 plate(vec2 uv, vec2 px, float alpha) {
    vec2 p = (uv - 0.5) * px;
    vec2 half_ = px * 0.5 - 1.0;
    float cut = min(px.y, 34.0) * 0.3;
    vec2 ab = abs(p);
    float d = sdBox(p, half_);
    float chamfer = (ab.x + ab.y) - (half_.x + half_.y - cut);
    d = max(d, chamfer * 0.7071);
    float body = aastep(d);
    if (body <= 0.001) return vec4(0.0);
    float grad = mix(0.92, 0.58, uv.y);
    vec4 res = vec4(PLATE.rgb, PLATE.a * grad * alpha * body);
    float edge = aastep(abs(d + 0.75) - 0.75);
    res = over(vec4(BONE, edge * 0.16 * alpha), res);
    return res;
}

vec4 line(vec2 q, vec2 a, vec2 b, float width, vec3 col, float alpha) {
    vec2 pa = q - a, ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    float d = length(pa - ba * h) - width;
    return vec4(col, aastep(d) * alpha);
}

vec4 widget(ivec3 d) {
    int id = d.r;
    int g = d.g, b = d.b;
    vec2 uv = hudUV;
    vec2 px = hudSize;
    float t = now();

    if (id == 0xC0) {
        // 체력. 30% 아래면 깜박인다.
        float v = frac16(d);
        vec3 a = v < 0.3 ? mix(DANGER, vec3(1.0, 0.45, 0.35), 0.5 + 0.5 * sin(t * 0.5)) : mix(vec3(0.84, 0.82, 0.76), vec3(0.96, 0.94, 0.88), v);
        vec3 c = v < 0.3 ? DANGER * 0.7 : vec3(0.62, 0.60, 0.55);
        return skewBar(uv, px, v, a, c, 14.0, true, 10);
    }
    if (id == 0xC1) {
        // 잔상: 빨갛게 줄어드는 몫. 체력 막대 뒤에 먼저 그려진다.
        return skewBar(uv, px, frac16(d), vec3(0.85, 0.16, 0.12), vec3(0.5, 0.08, 0.08), 14.0, false, 0);
    }
    if (id == 0xC2) {
        float v = frac16(d);
        return skewBar(uv, px, v, EMBER, EMBER_DIM, 6.0, true, 0);
    }
    if (id == 0xC3) {
        float v = float(g) / 255.0;
        vec4 r = ring(uv, px, v, px.x * 0.36, px.x * 0.46, mix(INFECT, DANGER, smoothstep(0.7, 1.0, v)), 0.5);
        return r;
    }
    if (id == 0xC4) {
        return plate(uv, px, 1.0);
    }
    if (id == 0xC5) {
        // 탄창 눈금: g 현재, b 최대
        float cur = float(g), mx = max(float(b), 1.0);
        float u = uv.x * mx;
        float cell = fract(u);
        float idx = floor(u);
        float gap = min(0.22, 2.0 * mx / px.x);
        float on = step(gap, cell) * step(cell, 1.0 - gap);
        float fill = idx < cur ? 1.0 : 0.0;
        vec3 c = cur / mx < 0.25 ? DANGER : BONE;
        return mix(vec4(c * 0.2, on * 0.34), vec4(c, on), fill);
    }
    if (id == 0xC6) {
        // 재장전 고리: g 시작, b 수명(2틱 단위)
        float life = max(float(b) * 2.0, 1.0);
        float p = clamp(age(g) / life, 0.0, 1.0);
        return ring(uv, px, p, px.x * 0.40, px.x * 0.47, EMBER, 0.4);
    }
    if (id == 0xC7) {
        // 조준점: g 벌어짐, b 상태(0 기본, 1 조준 중, 2 적 조준, 3 불가)
        vec2 q = (uv - 0.5) * px;
        float unit = px.x / 140.0;
        float gap = (5.0 + float(g) * 0.42) * unit;
        float len = (b == 1 ? 7.0 : 11.0) * unit;
        float w = max(0.75, 1.15 * unit);
        vec3 c = b == 2 ? DANGER : b == 3 ? vec3(0.5) : BONE;
        vec4 res = vec4(0.0);
        vec4 s = vec4(0.0);
        for (int i = 0; i < 4; i++) {
            vec2 dir = i == 0 ? vec2(1, 0) : i == 1 ? vec2(-1, 0) : i == 2 ? vec2(0, 1) : vec2(0, -1);
            s = over(line(q + vec2(0.0, 0.0), dir * gap, dir * (gap + len), w + 0.9, vec3(0.0), 0.55), s);
            res = over(line(q, dir * gap, dir * (gap + len), w, c, 0.95), res);
        }
        float dot_ = aastep(length(q) - w * 1.05);
        res = over(vec4(c, dot_ * 0.9), res);
        return over(res, s);
    }
    if (id == 0xC8) {
        // 적중 표시: g 시작, b 0 몸 1 머리 2 처치 3 머리 처치
        float a = age(g);
        float life = b >= 2 ? 11.0 : 7.0;
        if (a > life) return vec4(0.0);
        vec2 q = (uv - 0.5) * px;
        float unit = px.x / 96.0;
        float k = a / life;
        float gap = (6.0 + k * 4.0 + (b >= 2 ? 2.0 : 0.0)) * unit;
        float len = (b >= 2 ? 13.0 : 9.0) * unit;
        vec3 c = b == 1 ? EMBER : b >= 2 ? DANGER : BONE;
        float w = (b >= 2 ? 1.5 : 1.1) * unit;
        vec4 res = vec4(0.0);
        for (int i = 0; i < 4; i++) {
            vec2 dir = normalize(vec2(i < 2 ? 1.0 : -1.0, (i & 1) == 0 ? 1.0 : -1.0));
            res = over(line(q, dir * gap, dir * (gap + len), w, c, (1.0 - k * k)), res);
        }
        return res;
    }
    if (id == 0xC9) {
        float v = frac16(d);
        vec4 r = ring(uv, px, v, px.x * 0.42, px.x * 0.48, EMBER, 0.45);
        return r;
    }
    if (id == 0xCA) {
        // 시계 판: g 낮밤 진행(0~255), b 0 낮 1 해질녘 2 밤 3 새벽
        vec4 res = plate(uv, px, 0.92);
        // 아래쪽 호
        vec2 q = (uv - vec2(0.5, 0.0)) * px;
        float unit = px.y / 124.0;
        vec2 c0 = vec2(0.0, 12.0 * unit);
        float prog = float(g) / 255.0;
        float x = mix(-1.0, 1.0, prog);
        float barY = 94.0 * unit;
        float bar = aastep(abs(q.y - barY) - 1.2 * unit) * step(abs(q.x), 150.0 * unit);
        vec3 col = b == 2 ? COLD : b == 1 ? DANGER : b == 3 ? EMBER : BONE;
        res = over(vec4(col * 0.42, bar * 0.8), res);
        float fillBar = bar * step(q.x, x * 150.0 * unit);
        res = over(vec4(col, fillBar), res);
        float knob = aastep(length(q - vec2(x * 150.0 * unit, barY)) - 3.4 * unit);
        res = over(vec4(col, knob), res);
        return res;
    }
    if (id == 0xCB) {
        float v = frac16(d);
        vec3 a = v < 0.3 ? DANGER : EMBER;
        return skewBar(uv, px, v, a, a * 0.6, 4.0, true, 0);
    }
    if (id == 0xCC) {
        float v = frac16(d);
        return skewBar(uv, px, v, vec3(0.74, 0.72, 0.62), vec3(0.4, 0.38, 0.32), 2.0, true, 0);
    }
    if (id == 0xCD) {
        float v = frac16(d);
        vec4 res = skewBar(uv, px, v, vec3(0.92, 0.20, 0.14), vec3(0.42, 0.04, 0.05), 18.0, true, 20);
        return res;
    }
    if (id == 0xCE) {
        return skewBar(uv, px, frac16(d), vec3(1.0, 0.86, 0.55), vec3(0.7, 0.44, 0.2), 18.0, false, 0);
    }
    if (id == 0xCF) {
        // 피격 방향: g 각도, b 시작
        float a = age(b);
        if (a > 28.0) return vec4(0.0);
        vec2 q = (uv - 0.5) * 2.0;
        float ang = float(g) / 256.0 * TAU;
        vec2 dir = vec2(sin(ang), -cos(ang));
        float r = length(q);
        float da = dot(q / max(r, 0.001), dir);
        float wedge = smoothstep(0.80, 0.97, da);
        float band = smoothstep(0.66, 0.78, r) * (1.0 - smoothstep(0.86, 0.98, r));
        return vec4(DANGER, wedge * band * (1.0 - a / 28.0));
    }
    if (id == 0xD0) {
        // 나침반 항목: 글리프 그림. 띠 양끝에서 사라진다.
        vec4 c = glyph();
        return c;
    }
    if (id == 0xD1) {
        // 나침반 띠: 눈금은 서버가 보낸 yaw를 g,b로 받는다.
        float yaw = float(g * 256 + b) / 65536.0;
        float x = uv.x - 0.5;
        float deg = yaw * 360.0 + x * 620.0 / 300.0 * 90.0;
        float minor = abs(fract(deg / 15.0 + 0.5) - 0.5) * 15.0;
        float major = abs(fract(deg / 45.0 + 0.5) - 0.5) * 45.0;
        float pxPerDeg = px.x / (620.0 / 300.0 * 90.0);
        float tickMinor = aastep(minor * pxPerDeg - 0.7) * step(0.62, uv.y);
        float tickMajor = aastep(major * pxPerDeg - 0.9) * step(0.42, uv.y);
        float fadeK = 1.0 - smoothstep(0.34, 0.5, abs(x));
        vec4 res = vec4(BONE, max(tickMinor * 0.38, tickMajor * 0.86) * fadeK);
        float center = aastep(abs(x) * px.x - 1.1) * step(uv.y, 0.36);
        res = over(vec4(EMBER, center * 0.95), res);
        return res;
    }
    if (id == 0xD2) {
        // 팀 프레임: g 하위 4비트 줄, 상위 4비트 상태(0 정상, 1 쓰러짐, 2 감염체, 3 사망), b 체력
        float v = float(b) / 255.0;
        int st = g >> 4;
        vec3 a = st == 1 ? mix(DANGER, vec3(1.0, 0.6, 0.5), 0.5 + 0.5 * sin(t * 0.6)) : st == 2 ? INFECT : st == 3 ? vec3(0.3) : v < 0.3 ? DANGER : BONE;
        return skewBar(uv, px, v, a, a * 0.6, 4.0, true, 0);
    }
    if (id == 0xD3) {
        // 스킬 고리: g 준비도(255 준비됨)
        float v = float(g) / 255.0;
        vec3 c = v >= 1.0 ? EMBER : vec3(0.55);
        vec4 res = ring(uv, px, v, px.x * 0.40, px.x * 0.47, c, 0.5);
        vec2 q = (uv - 0.5) * px;
        float disc = aastep(length(q) - px.x * 0.40);
        res = over(res, vec4(0.03, 0.03, 0.035, disc * 0.6));
        if (v >= 1.0) {
            float pulse = 0.5 + 0.5 * sin(t * 0.25);
            float glow = smoothstep(px.x * 0.56, px.x * 0.45, length(q)) * smoothstep(px.x * 0.40, px.x * 0.47, length(q));
            res = over(vec4(EMBER, glow * 0.3 * pulse), res);
        }
        return res;
    }
    if (id == 0xD4 || id == 0xD5) {
        return plate(uv, px, 0.86);
    }
    if (id == 0xD6) {
        // 무전 판: g 투명도, 왼쪽에 소리 파형
        float a = float(g) / 255.0;
        vec4 res = plate(uv, px, a);
        vec2 q = uv * px;
        float bars = floor(q.x / 6.0);
        if (q.x > 96.0 * px.y / 92.0 && q.x < 170.0 * px.y / 92.0 && false) {
            res = res;
        }
        return res;
    }
    if (id == 0xD7) {
        // 큰 제목 띠: g 투명도. 가운데가 어둡게 깔리고 양옆으로 사라진다.
        float a = float(g) / 255.0;
        float xfade = 1.0 - smoothstep(0.08, 0.5, abs(uv.x - 0.5));
        float yfade = 1.0 - smoothstep(0.12, 0.5, abs(uv.y - 0.5));
        vec4 res = vec4(0.0, 0.0, 0.0, 0.62 * xfade * yfade * a);
        float lineY = aastep(abs(uv.y - 0.86) * px.y - 0.8) * (1.0 - smoothstep(0.02, 0.26, abs(uv.x - 0.5)));
        res = over(vec4(EMBER, lineY * a * 0.9), res);
        return res;
    }
    if (id == 0xD8) {
        float v = frac16(d);
        return skewBar(uv, px, v, DANGER, DANGER * 0.5, 6.0, true, 0);
    }
    if (id == 0xD9 || id == 0xDB) {
        vec4 c = glyph();
        c.a *= float(b) / 255.0;
        return c;
    }
    if (id == 0xDA) {
        // 화면 가장자리 표시: 글리프, b 투명도
        vec4 c = glyph();
        c.a *= float(b) / 255.0;
        return c;
    }
    return vec4(0.0);
}
#endif

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    #ifdef IS_GUI
    if (hudData.r != 0) {
        color = widget(hudData);
        color.a *= vertexColor.a;
        if (color.a < 0.004) {
            discard;
        }
        #ifndef OIT_ALPHA_ONLY
        fragColor = color;
        #endif
        return;
    }
    #endif

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
