#version 330
#extension GL_ARB_separate_shader_objects : require

// 불씨: 화면 마무리.
// 화면 왼쪽 아래 16픽셀에 서버와 정점 셰이더가 값을 찍는다. 슬롯 번호는 fx/Screen.java 와 item.vsh 와 같다.
//  0 흔들림(사건)  1 번쩍임(사건)  2 충격 흐림(사건)  3 피격(사건)  4 페이드(사건)
//  5 체력8 감염8 쓰러짐8    6 밤8 손전등8 편지함8    7 독가스8 핏빛달8 탈색8
//  8 표식 0xE5B3A1          9 투영22  10 투영32  11 투영11(12비트) 피치(12비트)
// 12 카메라 높이(12비트) 시간배속(12비트)  13 안개색 RGB  14 자막 음영8 스캔라인8 깊이흐림8  15 안개 농도8(128이 1배)
// 사건 슬롯 형식: 시작틱 8비트, 수명 6비트, 세기 6비트, 추가값 4비트
// 페이드 형식: 시작틱 8비트, 수명 6비트, 시작값 5비트, 끝값 5비트 (0이 투명, 31이 검정)

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D BloomSampler;
uniform sampler2D SoftSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const float PI = 3.14159265;

float now() {
    return GameTime * 24000.0;
}

ivec3 rawSlot(int i) {
    return ivec3(texelFetch(InSampler, ivec2(i, 0), 0).rgb * 255.0 + 0.5);
}

int slotBits(int i) {
    ivec3 b = rawSlot(i);
    return (b.r << 16) | (b.g << 8) | b.b;
}

// x: 진행도(0~1, 꺼져 있으면 2), y: 세기, z: 추가값
vec3 eventSlot(int i) {
    int d = slotBits(i);
    if (d == 0) return vec3(2.0, 0.0, 0.0);
    float start = float((d >> 16) & 255);
    float life = float(((d >> 10) & 63) + 1);
    float amp = float((d >> 4) & 63) / 63.0;
    float extra = float(d & 15);
    float age = mod(now() - start, 256.0);
    return vec3(age / life, amp, extra);
}

float hash12(vec2 p) {
    p = fract(p * vec2(443.897, 441.423));
    p += dot(p, p.yx + 19.19);
    return fract((p.x + p.y) * p.x);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1, 0)), f.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + 11.3;
        a *= 0.5;
    }
    return v;
}
float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 scene(vec2 uv) {
    return texture(InSampler, uv).rgb;
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    bool valid = slotBits(8) == 0xE5B3A1;

    vec2 uv = texCoord;
    float aspect = OutSize.x / OutSize.y;

    float shakeAmt = 0.0, impactAmt = 0.0, flashAmt = 0.0, hurtAmt = 0.0, fade = 0.0;
    vec3 flashCol = vec3(1.0);
    float seed = 0.0, hurtSide = 0.0;
    float hp = 1.0, infection = 0.0, downed = 0.0, night = 0.0, torch = 0.0, letterbox = 0.0;
    float gas = 0.0, bloodMoon = 0.0, desat = 0.0, scan = 0.0, dof = 0.0;
    float P11 = 1.5, P22 = -1.0, P32 = -0.1, pitch = 0.0, camY = 70.0;
    vec3 mistCol = vec3(0.5);
    float mistK = 1.0;

    if (valid) {
        vec3 s = eventSlot(0);
        if (s.x < 1.0) {
            float k = 1.0 - s.x;
            shakeAmt = s.y * k * k;
            seed = s.z;
        }
        s = eventSlot(1);
        if (s.x < 1.0) {
            flashAmt = s.y * (1.0 - s.x) * (1.0 - s.x);
            int c = int(s.z);
            flashCol = c == 1 ? vec3(0.7, 0.03, 0.04) : c == 2 ? vec3(1.0, 0.72, 0.32) : c == 3 ? vec3(0.0) : c == 4 ? vec3(0.62, 0.9, 0.25) : vec3(1.0);
        }
        s = eventSlot(2);
        if (s.x < 1.0) impactAmt = s.y * (1.0 - s.x);
        s = eventSlot(3);
        if (s.x < 1.0) {
            hurtAmt = s.y * (1.0 - s.x);
            hurtSide = s.z;
        }
        int f = slotBits(4);
        if (f != 0) {
            float start = float((f >> 16) & 255);
            float life = float(((f >> 10) & 63) + 1);
            float a = float((f >> 5) & 31) / 31.0;
            float b = float(f & 31) / 31.0;
            float age = mod(now() - start, 256.0);
            fade = mix(a, b, clamp(age / life, 0.0, 1.0));
        }
        vec3 v = texelFetch(InSampler, ivec2(5, 0), 0).rgb;
        hp = v.r; infection = v.g; downed = v.b;
        v = texelFetch(InSampler, ivec2(6, 0), 0).rgb;
        night = v.r; torch = v.g; letterbox = v.b;
        v = texelFetch(InSampler, ivec2(7, 0), 0).rgb;
        gas = v.r; bloodMoon = v.g; desat = v.b;
        P22 = float(slotBits(9)) / 16777215.0 * 4.0 - 2.0;
        P32 = float(slotBits(10)) / 16777215.0 * 2.0 - 1.0;
        int cam = slotBits(11);
        P11 = float((cam >> 12) & 4095) / 4095.0 * 8.0;
        pitch = (float(cam & 4095) / 4095.0 - 0.5) * PI;
        int cy = slotBits(12);
        camY = float((cy >> 12) & 4095) * 0.25 - 64.0;
        mistCol = texelFetch(InSampler, ivec2(13, 0), 0).rgb;
        v = texelFetch(InSampler, ivec2(14, 0), 0).rgb;
        scan = v.g; dof = v.b;
        mistK = texelFetch(InSampler, ivec2(15, 0), 0).r * 255.0 / 128.0;
    }

    float t = now();

    // 흔들림
    if (shakeAmt > 0.001) {
        vec2 off = vec2(sin(t * 3.7 + seed) + sin(t * 7.9 + seed * 2.1), cos(t * 4.3 + seed * 1.7) + cos(t * 8.7 + seed)) * 0.5;
        float roll = sin(t * 2.9 + seed * 3.0) * shakeAmt * 0.03;
        vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
        p = mat2(cos(roll), -sin(roll), sin(roll), cos(roll)) * p;
        p /= vec2(aspect, 1.0);
        uv = 0.5 + p / (1.0 + shakeAmt * 0.05) + off * shakeAmt * 0.02;
    }

    // 독가스와 높은 감염: 일렁임
    float woozy = max(gas, smoothstep(0.55, 1.0, infection) * 0.75);
    if (woozy > 0.002) {
        uv += vec2(sin(uv.y * 9.0 + t * 0.16), cos(uv.x * 7.0 + t * 0.13)) * 0.0065 * woozy;
    }

    vec3 col = scene(uv);

    // 충격: 방사 흐림과 색수차
    if (impactAmt > 0.002) {
        vec2 c0 = uv - 0.5;
        vec3 acc = vec3(0.0);
        float strength = impactAmt * 0.10;
        for (int i = 0; i < 8; i++) {
            float f = float(i) / 7.0;
            acc += scene(0.5 + c0 * (1.0 - strength * f));
        }
        col = acc / 8.0;
        vec2 dir = c0 * impactAmt * 0.02;
        col.r = mix(col.r, scene(uv + dir).r, 0.8);
        col.b = mix(col.b, scene(uv - dir).b, 0.8);
    } else {
        // 항상 있는 약한 색수차: 가장자리에서만
        vec2 c0 = uv - 0.5;
        float r2 = dot(c0, c0);
        vec2 dir = c0 * r2 * 0.0032;
        col.r = scene(uv + dir).r;
        col.b = scene(uv - dir).b;
    }

    // 깊이: 선형 거리와 시야 공간 위치
    float rawDepth = texture(DepthSampler, uv).r;
    float linear = 400.0;
    vec3 viewPos = vec3(0.0, 0.0, -400.0);
    vec3 rayDir = vec3(0.0, 0.0, -1.0);
    bool sky = rawDepth >= 0.99999 || rawDepth <= 0.00001;
    if (valid) {
        // 깊이 범위가 0~1 인 장치인지 투영 행렬에서 읽는다. P32가 -near에 가까우면 0~1이고, -2near에 가까우면 -1~1이다.
        bool zeroToOne = abs(P32) < 0.075;
        float ndcZ = zeroToOne ? rawDepth : rawDepth * 2.0 - 1.0;
        float denom = ndcZ + P22;
        linear = abs(denom) > 1e-7 ? P32 / denom : 1000.0;
        if (linear < 0.0 || linear > 2000.0) linear = 2000.0;
        vec2 ndc = uv * 2.0 - 1.0;
        rayDir = vec3(ndc.x * aspect / max(P11, 0.01), ndc.y / max(P11, 0.01), -1.0);
        viewPos = rayDir * linear;
    }

    // 데이터 픽셀 숨기기
    if (px.y < 1 && px.x < 16) {
        col = texelFetch(InSampler, ivec2(px.x, 2), 0).rgb;
        sky = true;
    }

    // ---- 밤의 어둠과 손전등 --------------------------------------------------
    // 달빛은 푸르게, 전등과 불은 따뜻하게 들어오도록 타임라인이 맞춰 뒀다.
    // 푸른 쪽(하늘빛만 받은 곳)은 눌러서 어둠으로 보내고, 따뜻한 쪽(불빛)은 그대로 둔다.
    if (night > 0.002) {
        float l = luma(col);
        float blueness = clamp((col.b - col.r) / max(l, 0.02) * 1.4, 0.0, 1.0);
        float lit = smoothstep(0.10, 0.34, l) * (1.0 - blueness * 0.86);
        float ambient = sky ? 0.92 : mix(0.42, 1.0, lit);
        vec3 nightCol = col * ambient;
        nightCol = mix(nightCol, vec3(luma(nightCol)) * vec3(0.72, 0.84, 1.08), (1.0 - lit) * 0.55);

        if (torch > 0.002 && !sky) {
            vec3 origin = vec3(0.22, -0.28, 0.0);
            vec3 L = viewPos - origin;
            float dist = length(L);
            vec3 ldir = L / max(dist, 0.001);
            float cosA = -ldir.z;
            float cone = smoothstep(0.900, 0.982, cosA);
            float spill = smoothstep(0.70, 0.93, cosA) * 0.22;
            // 전구 얼룩: 빛무리 안쪽에 약한 고리
            float ringy = 0.92 + 0.08 * sin(acos(clamp(cosA, 0.0, 1.0)) * 46.0);
            float atten = 1.0 / (1.0 + dist * dist * 0.0065);
            vec3 N = normalize(cross(dFdx(viewPos), dFdy(viewPos)));
            float ndl = clamp(dot(N, -ldir), 0.0, 1.0);
            float beam = (cone * ringy + spill) * atten * (0.30 + 0.70 * ndl) * torch;
            // 하늘빛의 푸른 끼를 걷어 원래 색에 가깝게 되돌린다.
            vec3 base = col * vec3(1.55, 1.25, 0.86);
            nightCol = max(nightCol, nightCol + base * beam * vec3(2.2, 2.05, 1.8));
        }
        if (torch > 0.002) {
            // 안개 속으로 번지는 빛줄기
            vec2 fromHand = (uv - vec2(0.56, 0.30)) * vec2(aspect, 1.0);
            float glowBeam = exp(-dot(fromHand, fromHand) * 3.2);
            nightCol += vec3(0.020, 0.018, 0.014) * glowBeam * torch;
        }
        col = mix(col, nightCol, night);
    }

    // ---- 낮게 깔리는 안개 ---------------------------------------------------
    if (valid && !sky) {
        vec3 world = vec3(viewPos.x, viewPos.y * cos(pitch) + (-viewPos.z) * sin(pitch), 0.0);
        float y = camY + world.y;
        float dist = length(viewPos);
        float heightK = exp(-max(y - 64.0, 0.0) * 0.16);
        float n = fbm(vec2(dist * 0.03 + t * 0.0015, uv.x * 5.0 + t * 0.002));
        float mist = (1.0 - exp(-dist * 0.016 * mistK * heightK * (0.6 + n * 0.8)));
        col = mix(col, mistCol, clamp(mist, 0.0, 0.85));
    }

    // 블룸
    vec3 bloom = texture(BloomSampler, uv).rgb;
    col += bloom * mix(0.42, 0.85, night);

    // 번진 화면: 쓰러짐, 독가스, 연출의 얕은 심도
    float blurAmt = clamp(downed * 0.8 + gas * 0.5 + smoothstep(0.75, 1.0, infection) * 0.35, 0.0, 1.0);
    if (dof > 0.002) {
        blurAmt = max(blurAmt, dof * smoothstep(6.0, 36.0, abs(linear - 14.0)));
    }
    if (blurAmt > 0.002) {
        col = mix(col, texture(SoftSampler, uv).rgb + bloom * 0.3, blurAmt);
    }

    // ---- 색보정: 낮은 먼지 낀 필름, 어두운 곳은 차갑게, 밝은 곳은 따뜻하게 --------
    float L = luma(col);
    col *= mix(vec3(0.90, 0.97, 1.10), vec3(1.07, 1.0, 0.90), smoothstep(0.06, 0.8, L));
    vec3 sc = clamp(col, 0.0, 1.0);
    vec3 s2 = sc * sc * (3.0 - 2.0 * sc);
    col = mix(col, s2, 0.30);
    float baseSat = 0.86 - desat * 0.86;
    col = mix(vec3(luma(col)), col, baseSat);

    // 핏빛 달: 전체를 붉게 민다
    if (bloodMoon > 0.002) {
        float l2 = luma(col);
        vec3 red = vec3(l2 * 1.5 + 0.015, l2 * 0.5, l2 * 0.44);
        col = mix(col, red, bloodMoon * 0.72);
    }

    // 비네트
    vec2 q = (texCoord - 0.5) * vec2(aspect / 1.78, 1.0);
    float r = length(q);
    col *= 1.0 - smoothstep(0.38, 0.92, r) * mix(0.30, 0.52, night);

    // ---- 몸 상태 -----------------------------------------------------------
    if (valid) {
        // 체력: 가장자리 핏빛과 탈색, 심장 박동
        if (hp < 0.5) {
            float danger = (0.5 - hp) / 0.5;
            float beat = pow(max(sin(t * (0.34 + danger * 0.2)), 0.0), 6.0);
            float n = fbm(q * 5.0 + vec2(0.0, t * 0.01));
            float m = smoothstep(0.70 - danger * 0.42, 0.98 - danger * 0.14, r + n * 0.28);
            col = mix(col, vec3(luma(col)), danger * 0.62);
            col = mix(col, vec3(0.30, 0.012, 0.02) * (0.5 + n), m * (0.42 + danger * 0.42 + beat * 0.16));
            col *= 1.0 - beat * danger * 0.10;
        }
        // 피격: 맞은 쪽 가장자리 번짐 (0 전체, 1 왼쪽, 2 오른쪽, 3 뒤)
        if (hurtAmt > 0.002) {
            float edge = r;
            if (hurtSide > 0.5 && hurtSide < 1.5) edge = max(0.0, -q.x * 1.25 + 0.15);
            if (hurtSide > 1.5 && hurtSide < 2.5) edge = max(0.0, q.x * 1.25 + 0.15);
            if (hurtSide > 2.5) edge = max(0.0, -q.y * 1.35 + 0.15);
            float n = fbm(q * 7.0 + seed);
            float m = smoothstep(0.34, 0.84, edge + n * 0.22);
            col = mix(col, vec3(0.42, 0.02, 0.03), m * hurtAmt * 0.92);
        }
        // 감염: 초록 핏줄이 가장자리에서 기어 들어온다
        if (infection > 0.01) {
            float n = abs(fbm(q * 13.0 + vec2(t * 0.004, 0.0)) * 2.0 - 1.0);
            float veins = smoothstep(0.075, 0.0, n);
            float reach = smoothstep(0.92 - infection * 0.62, 1.0 - infection * 0.2, r + 0.08);
            col = mix(col, vec3(0.20, 0.50, 0.08) * (0.5 + L), veins * reach * 0.86);
            col = mix(col, col * vec3(0.76, 1.04, 0.70), infection * 0.42);
        }
        // 쓰러짐: 시야가 좁아지고 숨 쉬듯 어두워진다
        if (downed > 0.01) {
            float breath = 0.5 + 0.5 * sin(t * 0.09);
            float tunnel = smoothstep(0.16 + breath * 0.05, 0.62, r);
            col = mix(col, vec3(luma(col)) * vec3(1.0, 0.6, 0.58), downed * 0.78);
            col = mix(col, vec3(0.02, 0.0, 0.0), tunnel * downed * 0.96);
        }
        // 독가스
        if (gas > 0.01) {
            float n = fbm(q * 3.2 + vec2(t * 0.006, -t * 0.004));
            col = mix(col, vec3(0.34, 0.46, 0.08) * (0.34 + n), gas * (0.28 + n * 0.32));
        }
    }

    // 필름 입자
    float grain = hash12(vec2(px) + fract(t * 0.618) * 311.0) - 0.5;
    col += grain * mix(0.018, 0.036, night) * (1.0 - L * 0.5);

    // 무전 화면 느낌의 주사선
    if (scan > 0.002) {
        float line = 0.5 + 0.5 * sin(float(px.y) * 1.6 + t * 0.9);
        col *= 1.0 - scan * 0.20 * line;
        col += scan * (hash12(vec2(px.y * 0.01, t)) - 0.5) * 0.05;
    }

    // 번쩍임
    if (flashAmt > 0.001) {
        col = mix(col, flashCol, flashAmt * 0.92);
    }

    // 편지함
    if (letterbox > 0.002) {
        float barH = letterbox * 0.118;
        float edge = min(texCoord.y, 1.0 - texCoord.y);
        col *= smoothstep(barH, barH + 0.0015, edge);
    }

    // 페이드
    if (fade > 0.001) {
        col *= 1.0 - fade;
    }

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
