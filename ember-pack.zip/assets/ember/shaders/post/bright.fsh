#version 330
#extension GL_ARB_separate_shader_objects : require

// 블룸 재료: 밝은 곳만 남긴다. 불꽃과 전등은 대체로 난색이라 난색에 조금 더 후하게 준다.
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float l = max(c.r, max(c.g, c.b));
    float warm = clamp((c.r - c.b) * 1.2, 0.0, 1.0);
    float k = smoothstep(0.90 - warm * 0.10, 1.0, l);
    k *= k;
    fragColor = vec4(c * k, 1.0);
}
